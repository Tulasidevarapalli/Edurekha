DROP DATABASE taskdb;
CREATE DATABASE taskdb;

use taskdb;

CREATE TABLE tasks(
	taskId INT(11) AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(20) NOT NULL,
        description  VARCHAR(50) NOT NULL,
dueDate VARCHAR(20) DEFAULT NULL,
priority VARCHAR(20) NOT NULL 
);


INSERT INTO tasks(taskId, title,description,dueDate,priority) VALUES 
(1,'DeveopsApplication', 'implement Rest functionalities for task', '29-09-2001','LOW'),
 
(2,'FrontendApplication', 'implement JavaScript functionalities for task', '26-04-1980','HIGH');
 