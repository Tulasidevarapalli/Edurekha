package com.accenture.lkm.beans;

import java.util.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

public class TaskBean {
	
	private Long taskId;
	@NotEmpty(message="title should not be empty")
	private String title;
	@NotNull(message="description should not be empty")
	private String description;
	@DateTimeFormat(pattern="dd-mm-yyyy")
	private Date dueDate;
	@NotEmpty(message="priority should not be empty")
	private String priority;
	
	public TaskBean() {
		
	}

	public TaskBean(Long taskId, String title, String description, Date dueDate, String priority) {
		super();
		this.taskId = taskId;
		this.title = title;
		this.description = description;
		this.dueDate = dueDate;
		this.priority = priority;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	@Override
	public String toString() {
		return "TaskBean [taskId=" + taskId + ", title=" + title + ", description=" + description + ", dueDate="
				+ dueDate + ", priority=" + priority + "]";
	}
	
	

}
