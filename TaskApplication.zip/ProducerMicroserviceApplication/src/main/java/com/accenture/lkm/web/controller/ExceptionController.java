package com.accenture.lkm.web.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.accenture.lkm.exceptions.PastDateException;
@ControllerAdvice
public class ExceptionController {
	@ExceptionHandler(PastDateException.class)
	public ResponseEntity<String>exceptionController(PastDateException e)
	{
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
	}
}
