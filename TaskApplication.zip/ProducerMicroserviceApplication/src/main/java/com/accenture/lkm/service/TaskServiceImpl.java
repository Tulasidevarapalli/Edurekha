package com.accenture.lkm.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.lkm.beans.TaskBean;
import com.accenture.lkm.dao.TaskDAOWrapper;
import com.accenture.lkm.exceptions.PastDateException;

@Service
public class TaskServiceImpl implements TaskService {
	@Autowired
	private TaskDAOWrapper taskDaoWrapper;
	
	public Long addTask(TaskBean taskBean) throws PastDateException{
		Date date=new Date();
		System.out.println(date);
		if(taskBean.getDueDate().before(date)) throw new PastDateException();
		return taskDaoWrapper.addTask(taskBean);
	}
	
	public List<TaskBean> getTasksByPriority(String priority){
		return taskDaoWrapper.getTasksByPriority(priority);
	}
}
