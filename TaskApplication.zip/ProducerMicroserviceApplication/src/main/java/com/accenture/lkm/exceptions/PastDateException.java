package com.accenture.lkm.exceptions;

public class PastDateException extends Exception{
	public PastDateException() {
		super("You cant enter a past Date");
	}

}
