package com.accenture.lkm.web.controller;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.accenture.lkm.beans.TaskBean;
import com.accenture.lkm.exceptions.PastDateException;
import com.accenture.lkm.service.*;

@RestController
public class TaskController {

	@Autowired 
	private TaskService taskService;
	
	
	@PostMapping(value="/addTask")
	public ResponseEntity<String> addTask(@Valid @RequestBody TaskBean taskBean, Errors errors ) {
		if(errors.hasErrors()) {
			String errorMessage=errors.getAllErrors().stream()
								.map(ObjectError::getDefaultMessage)
								.collect(Collectors.joining(","));
			
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Validation Error: "+errorMessage);
		}
	
		try {
			Long createdTaskId=taskService.addTask(taskBean);
			String successMessage=String.format("Task created successfully with ID: %d, ",
					createdTaskId);
			return ResponseEntity.status(HttpStatus.CREATED).body(successMessage);
			
		}catch(PastDateException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}
	
	@GetMapping(value="/getTasks/{priority}")
	public ResponseEntity<List<TaskBean>>getTasksByPriority(@PathVariable("priority") String priority){
		List<TaskBean> taskBeanList=taskService.getTasksByPriority(priority);
		if(taskBeanList.isEmpty()) {
			return new ResponseEntity<List<TaskBean>>(HttpStatus.NOT_FOUND);
		} 
		return  ResponseEntity.status (HttpStatus.OK).body(taskBeanList);
		
	}
}