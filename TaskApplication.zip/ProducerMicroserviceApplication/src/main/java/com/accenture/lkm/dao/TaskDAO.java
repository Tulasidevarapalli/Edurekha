package com.accenture.lkm.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.accenture.lkm.entity.TaskEntity;

public interface TaskDAO extends CrudRepository <TaskEntity, Integer> {
	
	List<TaskEntity> findByPriority(String priority);

}
