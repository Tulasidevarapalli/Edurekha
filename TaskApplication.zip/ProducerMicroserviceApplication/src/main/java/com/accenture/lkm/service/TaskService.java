package com.accenture.lkm.service;

import java.util.List;

import com.accenture.lkm.beans.TaskBean;
import com.accenture.lkm.exceptions.PastDateException;

public interface TaskService {
	Long addTask(TaskBean taskBean) throws PastDateException;
	List<TaskBean> getTasksByPriority(String priority);
}
