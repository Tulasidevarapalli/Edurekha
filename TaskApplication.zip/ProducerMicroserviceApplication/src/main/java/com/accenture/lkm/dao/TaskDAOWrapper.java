package com.accenture.lkm.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.accenture.lkm.beans.TaskBean;
import com.accenture.lkm.entity.TaskEntity;

@Repository
public class TaskDAOWrapper {

	@Autowired
	private TaskDAO taskDao;
	
	public Long addTask(TaskBean taskBean) {
		TaskEntity taskEntity = convertBeanToEntity(taskBean);
		taskDao.save(taskEntity);
		return taskEntity.getTaskId();
	}
	
	/*Iterator<OrderEntity> orderBeanIterator = orderDao.findAll().iterator();
		List<OrderBean> orderBeans = new ArrayList<OrderBean>();
		while (orderBeanIterator.hasNext()) {
			OrderEntity orderEntity = orderBeanIterator.next();
			orderBeans.add(new OrderBean(orderEntity.getOrderId(), orderEntity.getBurgerName(), orderEntity.getQuantity(),
				orderEntity.getTotalCost(), orderEntity.getDeliveryAddress()));
		}
		return orderBeans;
		
		*/
	
	public List<TaskBean> getTasksByPriority(String priority){
		Iterator<TaskEntity> taskEntityIterator=taskDao.findByPriority(priority).iterator();
		List<TaskBean> taskBeanList=new ArrayList<TaskBean>();
		while(taskEntityIterator.hasNext()) {
			TaskEntity taskEntity=taskEntityIterator.next();
			taskBeanList.add(new TaskBean(taskEntity.getTaskId(),
										taskEntity.getTitle(),
										taskEntity.getDescription(),
										taskEntity.getDueDate(),
										taskEntity.getPriority()));
		}
			
		
		return taskBeanList;
	}
	
	private TaskEntity convertBeanToEntity(TaskBean taskBean) {
		TaskEntity taskEntity= new TaskEntity();
		BeanUtils.copyProperties(taskBean, taskEntity);
		return taskEntity;
		
	}
	
	private TaskBean convertEntityToBean(TaskEntity taskEntity) {
		TaskBean taskBean= new TaskBean();
		BeanUtils.copyProperties( taskEntity,taskBean);
		return taskBean;
		
	}
	
}
