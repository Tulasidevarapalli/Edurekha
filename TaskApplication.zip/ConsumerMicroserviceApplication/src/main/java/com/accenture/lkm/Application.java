package com.accenture.lkm;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.accenture.lkm.beans.TaskBean;

@SpringBootApplication
public class Application {

	 public static RestTemplate restTemplate;
	 
	@Autowired 
	public void init() {
		restTemplate=new RestTemplate();
		
	}

	public static final String BASEURL="http://localhost:8090";
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		addTask();		
		getTasksByPriority("LOW");
    }
	
	
	public static void addTask() {
		TaskBean taskBean= new TaskBean();
		taskBean.setTaskId(34562L);
		taskBean.setTitle("Frontend design");
		taskBean.setDescription("use spring boot webservice");
		Date myDate=new Date(2025,02,13);
		taskBean.setDueDate(myDate);
		taskBean.setPriority("HIGH");
		

		HttpEntity<TaskBean> requestEntity=new HttpEntity<>(taskBean ,new HttpHeaders());
		
		ResponseEntity<String> response=restTemplate.postForEntity(BASEURL+"/addTask",requestEntity,String.class);
		
		System.out.println("create task response:"+response.getBody());
		System.out.println("Status Code:"+response.getStatusCode());
	
		
	}
	
	public static void getTasksByPriority(String priority) {
		ResponseEntity<TaskBean[]> response=restTemplate.getForEntity(BASEURL+"/getTasks/"+priority,TaskBean[].class);
		
		TaskBean[] tasks=response.getBody();
		System.out.println("Get All task Response: ");
		for (TaskBean task:tasks) {
			System.out.println(task);
		}
		System.out.println("Status code: " +response.getStatusCodeValue());
	}
	
	
}
